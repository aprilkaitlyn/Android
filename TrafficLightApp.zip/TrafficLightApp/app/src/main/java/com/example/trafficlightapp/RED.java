package com.example.trafficlightapp;

class RED {
}
