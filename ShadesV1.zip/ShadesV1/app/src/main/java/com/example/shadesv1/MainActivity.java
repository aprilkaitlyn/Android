package com.example.shadesv1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity  {

    private ConstraintSet set;
    private ConstraintLayout layout;
    private Button gold;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //change background color to brown
        layout = (ConstraintLayout) findViewById(R.id.CL_1);
        layout.setBackgroundColor(Color.parseColor("#c89b6d"));
        set = new ConstraintSet();
        set.clone(layout);


        //create blue button
        Button blue = new Button(this);
        blue.setBackgroundColor(Color.parseColor("#ac7d50"));
        blue.setText("blue");
        blue.setId(View.generateViewId());
        blue.setTag("btnblue");
        set.connect(blue.getId(), ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP, 50);
        set.connect(blue.getId(),ConstraintSet.RIGHT,ConstraintSet.PARENT_ID,ConstraintSet.RIGHT,0);
        set.connect(blue.getId(),ConstraintSet.LEFT,ConstraintSet.PARENT_ID,ConstraintSet.LEFT,0);
        set.applyTo(layout);
        layout.addView(blue);
        blue.setOnClickListener(ShadeChangeListener);

        //create plum button
        Button plum = new Button(this);
        plum.setBackgroundColor(Color.parseColor("#ac7d50"));
        plum.setText("plum");
        plum.setId(View.generateViewId());
        plum.setTag("btnplum");
        set.connect(plum.getId(), ConstraintSet.TOP, blue.getId(), ConstraintSet.BOTTOM, 10);
        set.connect(plum.getId(),ConstraintSet.RIGHT,ConstraintSet.PARENT_ID,ConstraintSet.RIGHT,0);
        set.connect(plum.getId(),ConstraintSet.LEFT,ConstraintSet.PARENT_ID,ConstraintSet.LEFT,0);
        set.constrainHeight(plum.getId(), 200);
        set.applyTo(layout);
        layout.addView(plum);
        plum.setOnClickListener(ShadeChangeListener);

        //create gold button
        Button gold = new Button(this);
        gold.setBackgroundColor(Color.parseColor("#ac7d50"));
        gold.setText("gold");
        gold.setId(View.generateViewId());
        gold.setTag("btngold");
        set.connect(gold.getId(), ConstraintSet.TOP, plum.getId(), ConstraintSet.BOTTOM, 10);
        set.connect(gold.getId(),ConstraintSet.RIGHT,ConstraintSet.PARENT_ID,ConstraintSet.RIGHT,0);
        set.connect(gold.getId(),ConstraintSet.LEFT,ConstraintSet.PARENT_ID,ConstraintSet.LEFT,0);
        set.constrainHeight(gold.getId(), 200);
        set.applyTo(layout);
        layout.addView(gold);
        gold.setOnClickListener(ShadeChangeListener);
    }


    private View.OnClickListener ShadeChangeListener = new View.OnClickListener() {

        @Override
        public void onClick(View v) {

            TextView response = new TextView(MainActivity.this);
            response.setLayoutParams(new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            response.setGravity(Gravity.CENTER);

            switch((String) v.getTag()){
                case "btnplum":
                    response.setText(R.string.plum_is);
                    break;
                case "btnblue":
                    response.setText(R.string.blue_is);
                    break;
                case "btngold":
                    response.setText(R.string.gold_is);
                    break;
            }
            response.setBackgroundColor(Color.parseColor("#ac7d50"));
            response.setId(View.generateViewId());
            layout.addView(response);

            set.connect(response.getId(), ConstraintSet.TOP, gold.getId(), ConstraintSet.BOTTOM, 50);
            set.connect(response.getId(),ConstraintSet.RIGHT,ConstraintSet.PARENT_ID,ConstraintSet.RIGHT,0);
            set.connect(response.getId(),ConstraintSet.LEFT,ConstraintSet.PARENT_ID,ConstraintSet.LEFT,0);
            set.constrainHeight(response.getId(), 400);
            set.applyTo(layout);
        }
    };
}


